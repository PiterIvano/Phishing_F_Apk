<style>
    input[type=text] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        background-color: #f8f8f8;
        font-size: 16px;
    }
    input[type=submit] {
        width: 100%;
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 2px solid #ccc;
        border-radius: 4px;
        background-color: #f8f8f8;
        font-size: 16px;
    }
    input[type=submit]:hover {
        background-color: #45a049;
    }
    label {
        font-family: "Arial";
        font-size: 20px;
    }
    h3 {
        font-family: "bookman";
        font-size: 20px;
    }
    </style>
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
            <title>Ver Contraseñas</title>
            <style>
                body {
                    background-color: #f2f2f2;
                }
                div {
                    margin: auto;
                    width: 50%;
                    padding: 10px;
                    border: 1px solid #ccc;
                    background-color: #f2f2f2;
                }
                h1 {
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div>
                <h1>Ver Contraseñas</h1>
                <?php
                try {
                    $archivo = fopen("Guardadas.txt", "r");
                    while(!feof($archivo)){
                        echo fgets($archivo);
                    }
                    fclose($archivo);
                } catch (Exception $archivo) {
                    echo "Error al abrir el archivo";
        
                }
                ?>
            </div>
        
        </body>
        <script>
            setTimeout(function(){
                location.reload();
            }, 5000);
        </script>
        </html>
    <?php
?>